# Review độc lập + test kịch bản — Dịch/REVIEW đợt 2 (translate-b2)

- **Date:** 2026-11-12
- **Đối tượng:** translate-b2 — Việc A (retry cloud khi Aurora limit, `cloud_retry.py`) + Việc B (bỏ gemma khỏi bước dịch khi NMT primary + REVIEW cloud). Fix log `docs/fixes/2026-11-11-translate-b2.md`, bản gốc trước b2 `.backup_edit_20261111_translate_b2\` (8 file).
- **Cách làm:** stage tar MỚI của V2 (md5 khớp đĩa: `translate.py` 9205af4a…, `server.py` d894926b…, `llm.py` 9e1de4a7…, `cloud_retry.py` 30d3201e…) → 2 cây cloud: `src` (b2 trên đĩa) và `new` (b2 + sửa review). Diff từng file với backup. Không HTTP :8801/:8802/:8000/:8083/:3377, không LLM/GPU, không git. Stub fastapi/yt_dlp NGOÀI cây V2 (chỉ để import `server.py`).
- **Backup đợt review:** `Z:\PinelineV2\.backup_edit_20261112_translate_b2_review\` (+ `Z:\PinelineV6\.backup_edit_20261112_translate_b2_review\` cho file .bat).

## Kết luận

**An toàn để restart :8801: CÓ**, với điều kiện:
1. Restart khi hàng đợi rảnh (hoặc user đồng ý) — như luật cũ.
2. **Không bấm translate-fill trước restart** (trạng thái trộn — xem fix log mục Hiệu lực).
3. Trước restart chạy `Z:\PinelineV6\scripts\test_v2_translate_b2.bat` trên Windows → kỳ vọng 0 fail (đã thêm `tests\test_translate_b2_review.py`).
4. Biết trước hành vi khi Aurora CHẾT HẲN (D1 dưới): câu NMT sót không có đường vá local → job dừng «dịch CHƯA XONG — còn N câu VI trống», cần bấm vá/Chạy tiếp khi Aurora sống lại. Không hỏng dữ liệu, không TTS câu trống, không lặp nóng. Muốn giữ đường gemma cũ cho trường hợp này: `TRANSLATE_FILL_MODEL=local`.

Thiết kế Việc B đúng (không còn đường nào switch gemma ở cấu hình cloud ngoài các đường quay về có chủ ý; cấu hình cũ chạy Y HỆT bản trước b2 — đã đối chiếu bằng test). Việc A có **1 lỗi cao + 3 lỗi trung bình + 1 thấp** ở cửa chờ chung — đã sửa trong `cloud_retry.py` (không đổi `translate.py`/`server.py`/`llm.py`).

## Kết quả test (cloud, số thật)

| Bộ | `src` (b2 trên đĩa) | `new` (b2 + review) |
|---|---|---|
| Nhóm dịch/review/pronoun (13 file: b2, b1, b1_scenarios, review_fail_not_rv, park_review_retry, review_parallel_workers, optimize_b5_b6, review_batches, pronoun_postpass, pronoun_consistency, translate_missing, review_pass1_upload, pronoun_qa_slim_plan) | 209 pass / 3 fail / 1 skip | 209 pass / 3 fail / 1 skip |
| `tests/test_translate_b2_review.py` (18 ca mới) | 9 fail / 9 pass (fail = lỗi H1/M1–M3/L1 + 2 hàm mới) | **18 pass** (lặp 8 lần cùng nhóm: ổn định) |
| Toàn bộ `tests/` (`--continue-on-collection-errors`) | 327 pass / 9 fail / 6 lỗi collect | 345 pass / 9 fail / 6 lỗi collect — **cùng danh sách fail** |

3 fail có sẵn: `test_pronoun_postpass::test_modernish_mixed`, `::test_detox_nguoi_ta`, `test_pronoun_consistency::test_filter_review_fixes_when_locked`. Fail/lỗi còn lại = môi trường cloud (sfx_lib ×3, restart_guard ×2, asr_demucs; collect: auto_publisher_dedup, meta_and_thumb, queue_jobs_api, server_split, source_link, upload_limit_stop). Lệnh: `AGENT_BRAIN=0 PYTHONPATH=<stub> SMOKE_MISSING=yt_dlp,soundfile python3 -m pytest -q -p no:cacheprovider <file>`. 1 ca cũ trong `test_translate_b2.py` đổi kỳ vọng (xem H1).

Đo bằng đồng hồ ảo (cùng test, trước → sau sửa):

| Kịch bản (Aurora 429 suốt) | `src` | `new` |
|---|---|---|
| 24 luồng `call_with_cloud_retry` (429 xen 503) | **8 531 s** (~2,4 giờ) | 760 s (47 request) |
| `run_review` 8 luồng, `REVIEW_LOCAL_FALLBACK=0` | **7 213 s** | 582 s |
| `_auto_gpu` THẬT (run_translate → review → cổng → run_review), fallback=0 / =1 | 3 620 s / 2 268 s | 581 s / 582 s |

## Phát hiện

### Đã sửa (`cloud_retry.py`, test kèm)

- **H1 — Cao — tổng thời gian chờ ∝ số luồng (fix log nói «tối đa ~7,5 phút, không nhân theo số luồng» — sai).** Mỗi luồng đếm 4 lần thử RIÊNG; chỉ probe được tăng `attempt`, nên khi cloud chết các luồng LẦN LƯỢT làm probe và mỗi luồng đốt đủ 30+60+120+240 s → 24 luồng ≈ 450 + 23×420 s. Cùng hiện tượng giữa các lô tuần tự (lô 2 lại chờ đủ 90 s…) và giữa các lần `run_review` trong một job (run_translate → auto review → cổng server → `_finish_review`). Job đứng ghế hàng giờ (Dừng vẫn ăn trong ≤ 2 s).
  Sửa: **ngân sách chờ CHUNG cho một đợt limit** trên `CloudGate` (`outage_start`, `last_fail_at`; `outage_budget_sec` = tổng backoff n lần × 1,25 + 15 s, mặc định ≈ 577 s, trần 3600 s). Quá ngân sách → `wait_turn` không chờ nữa, luồng gặp limit lần nữa bỏ cloud NGAY (gắn `_cloud_retry_exhausted` như cũ → fallback C9 / lô lỗi → park). Đợt «nguội» (không lỗi limit mới trong ≥ ngân sách) → đợt sau tính lại từ đầu (job sau vẫn được chờ đủ — test `test_outage_cools_down…`). Ca cũ `test_run_review_cloud_limit_exhausted_parks_without_switch` đổi kỳ vọng: 2 lô tuần tự chờ ≤ 127,5 s chung thay vì 2×90 s.
- **M1 — Trung bình — request bay TỪ TRƯỚC đợt limit trả OK mở cửa.** Với 24 luồng song song, request gửi trước khi Aurora chặn vẫn về OK → `success()` mở cửa → luồng vừa bị 429 bắn lại NGAY, đốt lượt thử không chờ (đo: lần 2 sau 0,25 s thay vì ~2 s/30 s). Sửa: `success(started_at)` bỏ qua request bắt đầu trước `outage_start`.
- **M2 — Trung bình — Retry-After lớn.** `Retry-After: 3600` bị cắt còn 900 s nhưng vẫn chờ tới 4 × 900 s = 1 giờ. Sửa: Retry-After lớn hơn ngân sách còn lại → bỏ cloud ngay (1 request, 0 s chờ). Retry-After hợp lý (vd 45 s) vẫn dùng.
- **M3 — Trung bình — thử lại sau timeout nhân thời gian treo.** `llm._chatgpt_chat` tự thử tới 4 model × số base × 3 lần, mỗi request timeout ≥ 900 s (`CHATGPT_TIMEOUT`) → một lần gọi lỗi «read timed out» có thể đã mất hàng giờ; b2 phân loại `transient` và gọi lại 4 lần nữa. Sửa: không BẮT ĐẦU lần thử mới khi lời gọi đã kéo dài ≥ max(600 s, 2 × ngân sách) (≈ 1155 s).
- **L1 — Thấp — probe chết vì `BaseException`** (KeyboardInterrupt/SystemExit) giữ quyền dò → luồng khác chờ thêm 15 s. Sửa: nhả probe trong `except BaseException`.
- Log hết lượt giờ in số lần thực (`đã thử lại k/N lần · <lý do bỏ sớm>`).

### Đã soát — OK

- **Khoá/ngủ:** `CloudGate._lock` chỉ giữ trong vài phép gán; mọi `_sleep` ngoài khoá. Không khoá lồng với `fb_state["lock"]` (C9 lấy khoá SAU khi `call_with_cloud_retry` trả/ném). Probe lỗi không-limit → `release_probe`; probe lỗi limit → `trip` reset `probe_since`; probe treo > 15 s → luồng khác đi (không deadlock). Test 24 luồng + `join(60)` không treo.
- **`.stop`:** kiểm trong `wait_turn` mỗi vòng và `_sleep_with_stop` mỗi ≤ 2 s; mọi chỗ gọi đều truyền `.stop` (`_review_chunk_with_fallback` qua `_run_job`, pass1 full/chunk, `_cloud_fill_call`). `CloudRetryStopped` chứa «stopped by user» → server/run_translate xử lý như Dừng; các `except Exception` ở pass1 đều re-raise nó. Test: 8 luồng đang chờ chung → `.stop` → cả 8 thoát < 2 s thật.
- **Phân loại lỗi** đối chiếu từng `raise` trong `llm.py`: 400/413/422 «(no-retry)» → không retry; 401/403 → không; 429 (response + `__cause__`) → limit; 5xx/timeout/ConnectionError → transient; `LLMUnavailable("… thất bại: None")` (model trả rỗng mãi) → transient (chấp nhận); file-QA lệch account → không retry.
- **Vòng lặp vô hạn:** retry hữu hạn (≤ 20 lần cấu hình, giờ thêm ngân sách chung); park/resume B2 tối đa `QUEUE_REVIEW_RETRY_MAX` lượt; cổng server → `run_review` không gọi ngược cổng. Cloud chết: `_auto_gpu` thật (test) dừng ở «dịch CHƯA XONG» / park `waiting_review`, không TTS, ≤ 60 lần gọi cloud, không gọi gemma.
- **Việc B — chỗ còn switch/local:** grep `switch_preset`/`_tmodel()`/`run_translate(`: switch gemma chỉ còn ở `_ensure_translate_preset` (cấu hình cũ, NMT lỗi/rỗng, plan sample-mode), C9 (`REVIEW_PRESET`), REVIEW local; server gọi `run_translate(batch=25)` chỉ khi gap thật/cấu hình cũ, `translate_fill`/stage translate gọi `run_translate` nhưng ở cấu hình cloud không switch. `_translate_safe` cứu câu đơn bằng `FALLBACK_MODEL or _rmodel()` — config hiện tại `FALLBACK_MODEL` trống → GPT, không local.
- **Hậu kỳ bước 0** chỉ trên câu vừa vá, bỏ manual (test: hậu kỳ gọi đúng `[3]`, câu manual và câu máy khác không đổi ở bước 0). `fill_pending` bị xoá khi câu được vá (bước 0, single-row, `_mark_fill_pending`).
- **Chữ ký:** `run_translate`/`run_review` giữ nguyên tham số + vị trí (server gọi positional `run_translate(wd, 25, target, False, None, "batch")`, `agent_qa_gate`, `routes_agent`); `_review_chunk_with_fallback`/`_pass1_upload_one_srt`/`build_plan` chỉ thêm tham số có mặc định; `scripts/` không gọi các hàm này. Vỏ `_run_*_impl` chỉ bọc `try/finally` log VRAM — không nuốt/đổi exception.
- **Cấu hình cũ = bản gốc:** `test_old_config_identical_to_pre_b2` chạy CÙNG 8 kịch bản (run_translate có/không auto review; review cloud OK/429/503/413; bước 0 vá + câu manual) trên `translate.py` backup và hiện tại với `REVIEW_CLOUD_RETRY=0` + `TRANSLATE_FILL_MODEL=local` → trace (switch preset, model từng lời gọi, thứ tự lô), `script.json` cuối, kết quả/lỗi **giống hệt**.
- **`_log_vram`:** `shutil.which` + `subprocess.run(timeout=3)`, `CREATE_NO_WINDOW`, mọi lỗi bỏ qua → tối đa ~3 s × 4 lần/job.

### Chưa sửa — đề xuất (thiết kế / đổi hành vi)

- **D1 — Trung bình — Aurora chết hẳn ⇒ câu NMT sót không có đường local.** Kể cả `REVIEW_LOCAL_FALLBACK=1`, bước dịch-lấp (run_translate + bước 0 REVIEW) chỉ dùng cloud → câu còn trống (`fill_pending=1`), `n_unrev` không đếm câu trống nên KHÔNG park B2 tự thử lại; job dừng «chưa đủ để TTS» chờ người bấm vá. Trước b2 gemma vá được. Đề xuất (chọn 1): (a) hết lượt cloud + `REVIEW_LOCAL_FALLBACK=1` → vá phần còn lại bằng đường cũ (switch gemma 1 lần); (b) `_auto_gpu` thấy `fill_pending` → park `waiting_review` có `review_retry_at` như B2.
- **D2 — Trung bình (có từ trước) — `llm._chatgpt_chat` tự thử 429 nội bộ** tới 12+ request/lần gọi và **đổi model** (gpt-6 → gpt-5-6-mini → auto) khi bị limit → mỗi «lần thử» của cửa chờ = cả chùm request, và REVIEW có thể âm thầm chạy bằng model khác. Đề xuất: khi gọi qua `cloud_retry`, 429 ném ngay (không đổi model, không tự retry) — để cửa chờ lo.
- **D3 — Thấp — quá ngân sách thì mọi luồng đang chờ cùng đi 1 lần** (≤ số worker request, vd 24) rồi bỏ cloud — bị chặn, giống hành vi trước b2.
- **D4 — Thấp — đợt limit còn «nóng» giữa job:** job mới / lượt park B2 (300 s < ngân sách 577 s) gặp limit là bỏ cloud ngay, không chờ backoff — có chủ ý (B2 tự giãn cách), ghi để khỏi bất ngờ khi đọc log.
- **D5 — Thấp — NMT ra rất ít câu** (n_mt > 0 nhưng phần lớn sót) → cả phim lên GPT tuần tự lô 20; chỉ quay về gemma khi n_mt == 0 và > 50 câu. Đề xuất ngưỡng theo tỉ lệ (vd sót > 50 %).
- **D6 — Thấp — hậu kỳ bước 0 chạy trên danh sách con:** `apply_style_polish` dùng cửa sổ zh 4 câu trước → mất ngữ cảnh câu liền kề (chỉ ảnh hưởng vài luật cần setup câu trước).
- **D7 — Thấp — `_process_gpu`** (đường ASR→dịch tay) gặp câu trống nay chạy `run_review` (bước 0 + soát câu mới) thay vì chỉ dịch vá — thêm ít thời gian GPT.
- **D8 — Rất thấp — `nvidia-smi` treo ở driver không kill được** → `subprocess.run` chờ `wait()` sau kill không timeout. Hiếm; có thể chạy trong thread daemon nếu gặp.

## File (review này)

| File | Thay đổi |
|---|---|
| `cloud_retry.py` | H1/M1/M2/M3/L1: ngân sách chờ chung (`outage_budget_sec`, `CloudGate.over_budget/budget_left/note_fail`, `wait_turn(budget)`), `success(started_at)`, trần thời gian lời gọi, nhả probe khi BaseException, log |
| `tests/test_translate_b2.py` | 1 ca đổi kỳ vọng (ngân sách chung giữa 2 lô) |
| `tests/test_translate_b2_review.py` (mới) | 18 ca: nhiều luồng + 429 dài + 5xx xen + `.stop` + probe chết; Retry-After lớn; request cũ không mở cửa; timeout dài; nguội đợt; phân loại lỗi thật; `run_review` 8 luồng; `_auto_gpu` thật khi cloud chết (fallback 0/1); manual + hậu kỳ; `fill_pending`; đối chiếu cấu hình cũ với backup |
| `Z:\PinelineV6\scripts\test_v2_translate_b2.bat` | thêm `tests\test_translate_b2_review.py` |
