# Dịch đợt 3 (translate-b3): cờ thử nghiệm chất lượng dịch — regex xưng hô mixed · REVIEW sửa xưng hô theo plan · gom câu cắt đôi · D1 park câu trống

- **Date:** 2026-11-12
- **Nguồn:** chủ dự án yêu cầu, dựa trên baseline golden `Z:\PinelineV6\docs\reviews\2026-11-11-translation-baseline.md` (xưng hô đúng 47,3 %: NMT 24–45 %, LLM 91 %; 20/23 câu cắt đôi lặp chưa gom), review kiến trúc `Z:\PinelineV6\docs\design\2026-11-11-translate-architecture-review.md` (K13, K19/K20, K23/K24, Q8, Q9) và review b2 `docs/reviews/2026-11-12-translate-b2-review.md` (D1).
- **Khu vực:** `translate.py` (`apply_style_polish`, `apply_pronoun_postpass`, `review_batch`, `run_translate` + hàm mới), `server.py` (`_auto_gpu`, `_queue_park_ready` + hàm mới), `tests/test_translate_b3.py` (mới). V6: `scripts/golden_ab.py` + `golden_ab.bat` + `test_v2_translate_b3.bat` (mới).
- **Status:** fixed trên đĩa V2 — **chỉ có hiệu lực sau restart :8801**. **MỌI thay đổi nằm sau cờ; mặc định = hành vi cũ y hệt** (đã chứng minh bằng test đối chiếu với bản gốc, xem Recheck).
- **Backup:** `Z:\PinelineV2\.backup_edit_20261112_translate_b3\` (`translate.py`, `server.py`, `docs/CHANGELOG.md`, `docs/STATE.md`, `docs/worklog/2026-11-12.md`).
- **Phạm vi:** không sửa `config.json` / `pineline.config.json` (mặc định nằm trong code). Không đổi prompt/văn phong/model khi cờ ở mặc định.

## Cờ (tóm tắt)

| Cờ | Mặc định | Bật để thử | Tác dụng khi bật |
|---|---|---|---|
| `PRONOUN_REGEX_MIXED` | `1` (như cũ) | `0` | Tắt các phép **đổi đại từ** tất định trên phim mixed (danh sách chính xác bên dưới). Luật polish khác giữ nguyên. |
| `REVIEW_PRONOUN_MASK` | `1` (như cũ, đã có từ trước) | `0` | REVIEW không che/đóng băng đại từ. Kèm `REVIEW_PRONOUN_PLAN_GUIDE` (mặc định `1`): thêm khối chỉ dẫn (G) xưng hô theo plan + giữ fix chỉ-đổi-đại-từ sang dạng có trong plan. |
| `REVIEW_PRONOUN_PLAN_GUIDE` | `1` | `0` = mask tắt nhưng prompt/lọc như trước b3 | Chỉ có tác dụng khi `REVIEW_PRONOUN_MASK=0`. |
| `HALFCUE_MERGE` | `0` (tắt) | `1` | Gom cue cắt đôi trước NMT/LLM, dịch như 1 câu, chia VI lại cho từng cue gốc, ghi `group_id`. |
| `HALFCUE_GAP` / `HALFCUE_MAX_CHARS` / `HALFCUE_MAX_CUES` | `0.35` s / `40` ký tự ZH / `3` (2–3) | | Ngưỡng gom. |
| `FILL_PENDING_PARK` | `0` (như cũ) | `1` | D1: câu NMT sót vá cloud thất bại → park `waiting_review` tự thử lại (B2) thay vì dừng «chưa đủ để TTS» chờ người. |

Cách đặt: biến môi trường **hoặc** thêm key vào `Z:\PinelineV2\pineline.config.json` (vd `"PRONOUN_REGEX_MIXED": "0"`) — đọc lúc gọi (`config.get`: env > file > mặc định), nhưng code b3 chỉ có sau **restart :8801**. Thử trên golden trước bằng `Z:\PinelineV6\scripts\golden_ab.bat` (mục A/B).

## Triệu chứng

1. Phim cổ phong/mixed (cả 14 job work đều `style_lock.mode=mixed`) bị là phẳng ta/ngươi/lão phu → tôi/cậu (9dedde: 38/38 lỗi xưng hô).
2. Plan đã có đúng cặp (anh–em, lão phu–tiểu tử) nhưng bản cuối bỏ qua: NMT không nhận plan, REVIEW bị mask đóng băng đại từ; kể cả tắt mask thì bộ lọc K20 `_filter_cosmetic_nmt_fixes` bỏ mọi fix chỉ đổi đại từ (không thuộc A/C/D/E/F) và prompt rule 3 dặn «giữ nguyên đại từ».
3. Câu ASR cắt đôi dịch từng mảnh → lặp/vô nghĩa (20/23 câu gắn `halfcue_dup` còn lại).
4. D1: Aurora chết hẳn → câu NMT sót không vá được, job dừng «còn N câu VI trống» chờ người bấm vá; `n_unrev` không đếm câu trống nên B2 không tự thử lại.

## Nguyên nhân

- `apply_style_polish` nhánh `_is_mixed_genre(plan)`: regex `\bngươi\b→cậu`, `\bta\b→tôi` (+ vá hậu quả «cậu tôi/hắn tôi») chạy cho mọi phim mixed, không xét plan.
- `review_batch`: mask ⟦Pn⟧ + bỏ fix đổi tập đại từ; khi mask tắt không có chỉ dẫn được sửa xưng hô + K20 bỏ fix.
- `run_translate`: dịch theo cue ASR, không gom.
- `server._auto_gpu`: nhánh `not ready` chỉ đóng dấu pending; `_queue_park_ready` coi `unrev == 0` là sẵn sàng.

## Sửa

### 1. `PRONOUN_REGEX_MIXED` (`translate._pronoun_regex_mixed_on`, `_cfg_flag`)

Khi `=0` **và** plan là mixed (`_is_mixed_genre`: `style_lock.mode=mixed` hoặc genre có đô thị/dị năng/tinh cầu/hệ thống + võ/chiến/khoa huyễn/huyền ảo/combat), các luật sau **bị tắt**:

`apply_style_polish` — khối «Mixed: ép xưng hô đời thường»:
1. `Ngươi→Cậu`, `ngươi→cậu`
2. `Ta→Tôi`, `ta→tôi` (kèm cơ chế giữ «ông ta/cô ta/chúng ta…» `_TA_KEEP_RE`)
3. vá «cậu tôi / Cậu tôi» → «hắn» (ZH có 他) / «cô ấy» (她) / «cậu ấy»; «hắn tôi» → «hắn»
4. ZH có 奴隶 (+你的/变成): «biến cậu tôi thành» / «biến cậu ấy thành» → «biến hắn thành»

(cài đặt: chạy khối như cũ rồi hoàn lại `vi` về trước khối khi cờ tắt — tương đương bỏ qua; đọc dễ đối chiếu với code cũ.)

`apply_pronoun_postpass` — khi plan mixed mà `_is_modernish_genre` vẫn True (chỉ xảy ra với `style_lock.mode=modern` + genre đô thị+võ):
5. detox `_detox_modern_pronouns` (Ngươi/ngươi→Cậu/cậu, Ta/ta→Tôi/tôi, vá «cậu tôi/hắn tôi»)
6. ép theo cặp plan: `ngươi`→`call` (cậu/mày/anh/em/chị/bạn), «Ta» đầu câu→«Tôi» khi `self=tôi`.
(Với `mode=mixed` 5–6 vốn đã không chạy vì `_is_modernish_genre` trả False — cờ chặn nốt ca kia.) Biểu thức `if modern or _is_modernish_genre(plan)` đổi thành `if modern` (tương đương khi cờ mặc định).

**Giữ nguyên** (không phải đổi xưng hô ngôi 1/2): mọi luật polish khác — 穷酸/打天下/好大力气/眼馋/脑子进水/嘲讽/废什么话/没大没小/一股奇怪的力量/«Tôi đã đến từ»/觉醒者/số 亿-vạn tỷ/过山, nhánh mixed phần thuật ngữ (Thập Bát Tầng Ấn Ký, Tinh cầu, huyết thống, 废什么话→phí lời), `normalize_vi_thousands`, `apply_asr_stutter_heal`, `apply_halfcue_dangling_heal`, `script_lint.autofix_rows` (gồm `_fix_kin` «anh tôi»→«anh ta» khi ZH là 他 — sửa ngôi 3, áp mọi thể loại).

**Không đổi** (đã soát): `pronoun_register_policy` (chỉ chạy trong `agent_pronoun_pass` khi `PRONOUN_TITLE_POLICY=1`, và đi chiều NGƯỢC: «cậu/ông»→«ngươi» trong cửa sổ có danh xưng bậc — không là phẳng cổ phong, nên không tắt); `agent_pronoun_pass.scan` (chỉ gắn cờ «còn ngươi» khi modern, sửa bằng LLM); `pronoun_consistency` (không regex thay); prompt dịch/REVIEW («CẤM Ta/Ngươi nếu đô thị/mixed» trong `_mixed_address_rules`/prompt lô) — **không** thuộc cờ này (đổi prompt = việc khác, ghi ở Rủi ro).

### 2. REVIEW mask tắt → khối (G) (`_review_pron_guide_on`, `_review_pron_guide_block`, `_plan_pronoun_forms`, `_pronoun_plan_fixes`)

- Xác nhận `REVIEW_PRONOUN_MASK=0` tắt được qua config/env (đọc lúc gọi `_review_pronoun_mask_on`).
- Khi mask TẮT và `REVIEW_PRONOUN_PLAN_GUIDE` bật (mặc định): system prompt REVIEW thêm khối «(G) XƯNG HÔ THEO PLAN — lượt này ĐẠI TỪ KHÔNG BỊ KHOÁ, ĐƯỢC SỬA khi lệch cặp đã chốt» + danh sách ≤ 24 cặp `who → to: «self» / «call»` (bảng XƯNG HÔ đầy đủ vẫn ở plan_block như cũ); dặn không chắc người nói → giữ, cổ phong đúng thì CẤM đổi thành tôi/cậu.
- Bộ lọc: trước `_filter_cosmetic_nmt_fixes`, tách các fix **chỉ đổi đại từ** (phần còn lại của câu giống hệt sau khi che đại từ, so không phân biệt hoa/thường + dấu câu) mà mọi dạng MỚI thêm vào đều thuộc self/call trong `plan.pronouns` → giữ (K20 vốn bỏ). Fix khác vẫn qua K20 như cũ; sau đó `filter_review_fixes_for_lock` như cũ (mixed → không lọc). Câu `manual` không bao giờ nhận.
- Mask BẬT (prod): prompt, payload, lọc **giống hệt** trước b3 (test đối chiếu).

### 3. `HALFCUE_MERGE` (`halfcue_groups`, `halfcue_units`, `halfcue_split_vi`, `halfcue_expand`, `_halfcue_cfg`)

- **Nhóm:** cue liên tiếp theo thứ tự ASR; cue trước KHÔNG kết thúc bằng `。！？…!?．` (bỏ qua ngoặc/nháy đóng ở đuôi); khoảng nghỉ `start(sau) − end(trước) ≤ HALFCUE_GAP`; tổng ký tự ZH (bỏ dấu) ≤ `HALFCUE_MAX_CHARS`; tối đa `HALFCUE_MAX_CUES` cue; cue ZH rỗng không gom. `group_id = "hc<i đầu>"`.
- **Dịch:** NMT primary/hint (`mt_zh_vi.draft_rows`) và LLM (`_translate_safe` qua `_fill_chunk_hc` ở lô chính, vá oneshot-miss, các vòng vá missing; `translate_oneshot`) nhận 1 đơn vị `{i: i đầu, start: start đầu, end: end cuối, text: ZH nối}` (hint: `mt_vi` = nối gợi ý NMT các cue).
- **Chia lại** (`halfcue_split_vi`): mỗi điểm cắt chọn ranh giới sau dấu `, ; : — – … . ! ?` gần vị trí tỉ lệ độ dài ZH nhất (lệch ≤ max(6, 20 %) ký tự), không có thì ranh giới từ gần nhất. **Không cue nào trống** — mỗi cue gốc nhận một phần có chữ; `start/end/zh/spk/…` của từng cue giữ nguyên (TTS/sub dùng script.json theo cue như cũ → không vỡ timing, cổng missing không đổi). Không chọn phương án `merged_into`/cue rỗng vì `count_script_missing`, `translate_ready_for_tts`, TTS và cổng D1 đều coi `vi=""` là thiếu.
- **Không chia được** (VI ít từ hơn số cue): nhóm vào `hc_failed`, các cue dịch lẻ (NMT: gọi `draft_rows` lần 2 chỉ cho các cue đó; LLM: `_fill_chunk` lẻ) — như khi tắt cờ. VI nhóm rỗng → các cue thiếu như câu thường, vòng vá sau xử lý.
- `group_id` ghi vào hàng script (trường thêm, T18 giữ); hint: chỉ ghi khi LLM dịch xong nhóm.
- **Không áp:** đường vá tại chỗ script post-split (i đã đánh lại), REVIEW bước 0 vá câu trống (`run_review`), `translate_alts`.

### 4. D1 — `FILL_PENDING_PARK` (`server._fill_pending_park_on`, `_n_fill_pending(_rows)`, `_park_fill_pending`)

- `_auto_gpu`, nhánh `not ready` (sau cổng review_fill + REVIEW): nếu cờ bật, còn câu `fill_pending=1` (VI trống), không coverage gap, và cổng là `review_fill` (NMT primary + REVIEW cloud) → đóng dấu như B2: `translate.status=pending`, `cur_text «soát dở — còn N câu VI trống (cloud vá lỗi), tự thử lại sau 300s»`, `agent.held_at=waiting_review`, `review_retries+1`, `review_retry_at=now+QUEUE_REVIEW_RETRY_SEC`; quá `QUEUE_REVIEW_RETRY_MAX` → `review_failed` + `hold_after_translate` (cần người). Runner trả `held` → queue giữ ghế.
- Bộ đếm lượt thử không bị khối «Soát xong (unrev=0) → gỡ waiting_review» xoá khi còn câu `fill_pending` (cờ bật).
- `_queue_park_ready`: `waiting_review` mà còn câu `fill_pending` (cờ bật) → KHÔNG coi `unrev==0` là sẵn sàng; chờ tới `review_retry_at` như B2 (không lặp nóng).
- Lượt chạy lại: `run_translate` (NMT câu trống → vá cloud) → cổng → REVIEW bước 0 → vá được thì đi tiếp TTS như thường.
- **Tôn trọng `TRANSLATE_FILL_MODEL=local`:** khi đó `_cloud_fill_model` = None → không có `fill_pending`, cổng = `translate` → đường gemma cũ, D1 không park (test).

## A/B trên golden (V6) — `Z:\PinelineV6\scripts\golden_ab.py` (+ `golden_ab.bat`)

Chạy trên Windows **khi V2 rảnh**: dựng job tạm `D:\PinelineV6_work\golden_ab\<job>_<variant>\` (CHỈ đọc `asr.json` cửa sổ golden ±20/3 câu, `glossary.json`, `style_lock.json`, `pronoun_lock.json`, `context_pack.json`, `queue_opts` từ `D:\PinelineV2_work\<job>`; từ chối `--out-root` nằm trong work/cây V2; manifest tạm không có `request.title` + `series_glossary.save_from` no-op → không ghi bảng bộ chung), chạy `run_translate(auto_review=False)` + `run_review` của code `Z:\PinelineV2` trong tiến trình con (cwd = job tạm) với env từng biến thể, chấm bằng `eval_translation.py` → `docs/reviews/2026-11-12-golden-ab.md` (+ `.json`).

Biến thể: `base`, `regex_off`, `mask_off`, `regex_mask_off`, `nmt_hint`, `nmt_hint_regex_mask_off`, `halfcue`. An toàn chung: `PINELINE_FLAG_PRESET_SWITCH=0` (guard có sẵn trong `preset_switcher.switch_allowed`), `AUTO_SWITCH_PRESETS=0`, `REVIEW_LOCAL_FALLBACK=0`, `TRANSLATE_FILL_MODEL=auto`, `AGENT_BRAIN=0`. `nmt_hint*` dịch bằng `--hint-model` (mặc định `AURORA_REVIEW_MODEL`/`REVIEW_MODEL` = cloud), không dùng gemma local.

```
cd /d Z:\PinelineV6
scripts\golden_ab.bat                       :: dry-run: in kế hoạch (cửa sổ, file nguồn, env), không ghi/chạy
scripts\golden_ab.bat run                   :: chạy 4 job × 7 biến thể (hỏi YES) — GPU + GPT/Aurora
scripts\golden_ab.bat run --variants base,regex_mask_off --jobs 9dedde16e35b --yes
scripts\golden_ab.bat score                 :: chấm lại job tạm đã chạy
scripts\golden_ab.bat source                :: không LLM: chấm script.json hiện có của V2 (kiểm pipeline chấm)
```
Job tạm đã có kết quả thì bỏ qua (resume); `--force` chạy lại (bản cũ chuyển vào `_old\`).

## Recheck

**Đã chạy ở cloud** (tar V2 mới, md5 khớp đĩa: `translate.py` 9205af4a…, `server.py` d894926b…, `cloud_retry.py` 9b6f0969… (bản tiefix của orchestrator); stub fastapi/yt_dlp NGOÀI cây V2; không HTTP/LLM/GPU):

| Bộ | Trước b3 (bản gốc) | Sau b3 |
|---|---|---|
| `tests/test_translate_b3.py` (23 ca mới) | — | **23 pass** |
| Nhóm dịch/review/pronoun (14 file: b2, b2_review, b1, b1_scenarios, review_fail_not_rv, park_review_retry, review_parallel_workers, optimize_b5_b6, review_batches, pronoun_postpass, pronoun_consistency, translate_missing, review_pass1_upload, pronoun_qa_slim_plan) | 225 pass / 4 fail / 2 skip | 225 pass / 4 fail / 2 skip — cùng danh sách |
| Toàn bộ `tests/` (`--continue-on-collection-errors`) | 343 pass / 10 fail / 6 lỗi collect | 366 pass / 10 fail / 6 lỗi collect — **cùng danh sách fail** |

4 fail nhóm: 3 có sẵn (`test_pronoun_postpass::test_modernish_mixed`, `::test_detox_nguoi_ta`, `test_pronoun_consistency::test_filter_review_fixes_when_locked`) + `test_translate_b2_review::test_stale_inflight_success_does_not_reopen_gate` — fail cả trên bản gốc với `cloud_retry.py` tiefix (không do b3; báo orchestrator). 2 skip = test đối chiếu bản trước b2 (cloud không có `.backup_edit_20261111_translate_b2`).

Test đối chiếu mặc định = bản gốc (`test_default_identical_to_pre_b3`, subprocess nạp `translate.py` từ `.backup_edit_20261112_translate_b3\` và bản mới): hậu kỳ (`apply_hard_term_locks` + `apply_style_polish` + `apply_pronoun_postpass`) trên 12 câu mẫu × 4 plan (mixed / modern-genre-mixed / modern / ancient) **và trên 567 câu `vi_system` golden thật** (khi có `Z:\PinelineV6\data\golden` hoặc `B3_GOLDEN_DIR`), `review_batch` (prompt system/user + kết quả) × 4 plan, `run_translate` NMT primary + hint (trace NMT/LLM/switch + script.json) → **giống hệt** ở cấu hình prod (`REVIEW_PRONOUN_MASK=1`) và ở `REVIEW_PRONOUN_MASK=0` + `REVIEW_PRONOUN_PLAN_GUIDE=0`. Đối chứng `test_flags_on_actually_change_something`: bật cờ thì khác.

`golden_ab.py` đã kiểm: cloud — chạy thật pipeline (con trỏ V2 giả, golden thật) 2 job × 2 biến thể: env đúng từng biến thể, chấm + ghi md/json; VM (đọc work V2 thật, không LLM): `--dry-run` (4 job, cửa sổ 163–167 câu, zh khớp golden 0–1 lệch), `--score-source` tái lập đúng baseline (xưng hô 47,3 %, 128 câu sai, chrF 75,0, halfcue còn 20), `--prepare-only` dựng job tạm vào `Z:\PinelineV6\scratch\golden_ab_check\`, guard `--out-root` trong work V2 → từ chối. Số nhóm half-cue với ngưỡng mặc định trên cửa sổ golden: 33/41/54/22 nhóm (82/108/133/50 cue trên ~165) — d1e0 15/19 câu `halfcue_dup` nằm trong nhóm, 9ded 4/4.

**Chỉ kiểm được trên Windows:** `Z:\PinelineV6\scripts\test_v2_translate_b3.bat` (kỳ vọng như cloud: b3 23 pass; fail chỉ là các fail có sẵn) — chạy trước restart :8801. Chạy A/B thật (`golden_ab.bat run`) khi V2 rảnh. Sau restart với cờ bật, log cần thấy: `[halfcue] HALFCUE_MERGE=1 · N nhóm`, `[halfcue] NMT: … đơn vị gom · … cue chia lại`, `[auto] <job>: còn N câu VI trống (cloud vá lỗi) — PARK waiting_review (lượt k/3)`.

## Rủi ro

- **Cờ bật = hành vi mới chưa đo chất lượng thật** — quyết bằng `golden_ab` trước khi bật prod. `regex_off` một mình có thể không đổi nhiều nếu NMT không sinh ta/ngươi (baseline §5); kỳ vọng lớn nhất ở `nmt_hint_regex_mask_off`.
- `regex_off` trên phim đô thị thật mà plan lỡ là mixed: NMT/LLM sinh «ta/ngươi» sẽ không bị ép về tôi/cậu (prompt vẫn cấm Ta/Ngươi cho mixed). Prompt «CẤM Ta/Ngươi nếu đô thị/mixed» và `_mixed_address_rules` («CẤM tại hạ/bổn tọa») vẫn đẩy LLM về hiện đại trên phim cổ phong gắn nhãn mixed — chưa sửa (ngoài phạm vi cờ regex; là việc K23/M3/PronounResolver).
- `mask_off`: REVIEW được đổi đại từ → có thể dao động nếu plan sai cặp/đoán sai người nói; chỉ giữ fix sang dạng có trong plan, phần còn lại câu phải y hệt.
- `HALFCUE_MERGE`: ngưỡng mặc định gom NHIỀU (≈ 30–80 % cue ở cửa sổ golden vì ASR hay không có dấu kết câu) → chia lại theo tỉ lệ độ dài có thể đặt ranh giới VI lệch ý so với cue ZH (đọc phụ đề/TTS lệch nửa nhịp); không cue nào trống, timing giữ. Cân nhắc giảm `HALFCUE_GAP`/`HALFCUE_MAX_CHARS` theo kết quả A/B. Câu cắt đôi kiểu ASR LẶP (đã có 。 ở mảnh trước, vd d1e0 #2498/#2499) không được gom — cần REVIEW (E) hoặc M1.
- D1: thêm tối đa `QUEUE_REVIEW_RETRY_MAX` (3) lượt chạy lại `_auto_gpu` cách nhau 300 s (mỗi lượt NMT lại câu trống + thử cloud trong ngân sách chờ chung) rồi `review_failed`. Ghế queue bị giữ trong thời gian đó (như B2).
- Không có trace thật trên job prod; đối chiếu mặc định chỉ qua test (hậu kỳ chạy trên dữ liệu golden thật, prompt/run_translate trên dữ liệu giả).
