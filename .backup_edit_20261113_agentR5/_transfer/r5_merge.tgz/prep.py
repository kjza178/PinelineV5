import sys, hashlib, shutil
from pathlib import Path
H=Path.home()/"mnt"
V2=H/"PinelineV2"; B=V2/".backup_edit_20261113_agentN"; V5=H/"PinelineV5"
sys.path.insert(0,str(V5/"scripts"))
import sync_from_v2 as s
plan=s.build_plan(V2,V5,None); dotted=plan["dotted"]
files={"agent_hold.py":"agents/agent_hold.py","agent_heal.py":"agents/agent_heal.py","agent_brain.py":"agents/agent_brain.py",
"agent_brain_notify.py":"agents/agent_brain_notify.py","agent_brain_context.py":"agents/agent_brain_context.py",
"routes_agent.py":"http_routes/routes_agent.py","tests/test_agent_brain_notify.py":"tests/test_agent_brain_notify.py",
"tests/test_brain_finished_hold.py":"tests/test_brain_finished_hold.py"}
out=Path("w"); out.mkdir(exist_ok=True)
def tx(p,rel):
    t,crlf,bom=s.read(p); t,_=s.rewrite_imports(t,dotted)
    d=rel.count("/")
    if not rel.startswith("tests/"):
        t,_,left=s.rewrite_file_paths(t,d)
        if left: print("WARN __file__",rel,left)
    return t
for src,rel in files.items():
    n=src.replace("/","__")
    for tag,p in (("base",B/src),("theirs",V2/src)):
        if p.exists(): (out/f"{n}.{tag}").write_text(tx(p,rel),encoding="utf-8")
        else: print("missing",tag,p)
    o=V5/rel
    if o.exists():
        t,crlf,bom=s.read(o); (out/f"{n}.ours").write_text(t,encoding="utf-8"); print(rel,"crlf",crlf,"bom",bom,hashlib.md5(o.read_bytes()).hexdigest())
    else: print("missing ours",o)
