# Worklog 2026-11-12

## ~sáng — Review độc lập + test kịch bản translate-b2

- **Yêu cầu:** review/test khó tính đợt translate-b2 (cloud_retry + bỏ gemma khỏi bước dịch): race/deadlock cửa chờ, tổng thời gian chờ, Retry-After, phân loại lỗi llm.py, hậu kỳ câu vá, fill_pending, cổng server, vòng lặp, chữ ký, chế độ cũ y hệt trước b2; tự sửa lỗi thật.
- **Đã làm:** stage tar mới V2 → 2 cây cloud (b2 / b2+review); diff 4 file code với `.backup_edit_20261111_translate_b2\`; đo bằng đồng hồ ảo: 24 luồng Aurora 429 suốt chờ 8 531 s (∝ số luồng). Sửa `cloud_retry.py` (ngân sách chờ chung, request cũ không mở cửa, Retry-After lớn, trần thời gian lời gọi, nhả probe). Test mới `tests/test_translate_b2_review.py` (18 ca, gồm `_auto_gpu` thật khi cloud chết và đối chiếu cấu hình cũ với bản trước b2); backup `.backup_edit_20261112_translate_b2_review\`; ghi file + kiểm md5 trước/sau.
- **Kết quả / còn treo:** cloud: b2_review 18/18, b2 47/47, nhóm dịch/review 209 pass/3 fail có sẵn (trước = sau), toàn bộ tests 345 pass, cùng danh sách fail môi trường. Kết luận: an toàn restart :8801 (queue rảnh, không translate-fill trước, chạy `Z:\PinelineV6\scripts\test_v2_translate_b2.bat`). Đề xuất chưa làm: D1 (Aurora chết hẳn → câu sót không vá local), D2 (llm.py tự thử/đổi model khi 429). Không LLM/GPU, không HTTP các cổng, không git.

## ~trưa — translate-b3: cờ thử nghiệm chất lượng dịch (mặc định tắt)

- **Yêu cầu:** sau baseline golden (xưng hô 47,3 %), thêm cờ: tắt regex đổi đại từ nhánh mixed, REVIEW được sửa xưng hô theo plan khi mask tắt, gom câu cắt đôi trước dịch, D1 park câu trống khi cloud chết; script A/B trên golden cho chủ dự án chạy; mặc định = hành vi cũ, chứng minh bằng test.
- **Đã làm:** `translate.py` (`_cfg_flag`, `_pronoun_regex_mixed_on`, khối (G) + `_pronoun_plan_fixes` trong `review_batch`, `halfcue_*` + `_fill_chunk_hc` trong `run_translate`), `server.py` (`_park_fill_pending`, `_queue_park_ready`), `tests/test_translate_b3.py` (23 ca). V6: `scripts/golden_ab.py` + `.bat`, `scripts/test_v2_translate_b3.bat`. Backup `.backup_edit_20261112_translate_b3\`; kiểm md5 đĩa trước/sau ghi.
- **Kết quả / còn treo:** cloud: b3 23/23; nhóm dịch/review 225 pass/4 fail (trước = sau, 1 fail mới do `cloud_retry.py` tiefix, có cả trên bản gốc); toàn bộ tests 343→366 pass, cùng danh sách fail. Đối chiếu mặc định với bản gốc: giống hệt (hậu kỳ trên 567 câu golden, prompt REVIEW, run_translate). VM: `golden_ab --score-source` tái lập baseline 47,3 %. Chưa: chạy A/B thật (cần V2 rảnh, GPU+GPT), test trên Windows (`test_v2_translate_b3.bat`), restart :8801. Không LLM/GPU, không HTTP các cổng, không git.

## ~chiều — translate-simple: luồng dịch mới sau cờ TRANSLATE_PIPELINE=simple

- **Yêu cầu:** chủ dự án duyệt thiết kế luồng 6 bước (plan ∥ NMT → review cloud 1 lần/lô áp xưng hô theo plan → hậu kỳ tất định không regex đại từ → bộ kiểm cờ → vá ≤2 lượt → cổng park/HOLD), package mới trong V2, rẽ nhánh server tối thiểu, biến thể golden A/B, test + docs.
- **Đã làm:** `translate_simple/` (11 module), `data/lexicon/idioms_zh_vi.json`, `server.py` (rẽ nhánh `_auto_gpu`/`_process_gpu`/`_run_stage`/`_translate_flow`, `_queue_park_ready` + `simple_park`), `tests/test_translate_simple.py` (26 ca). V6: `scripts/golden_ab.py` biến thể `simple`, `scripts/test_v2_translate_simple.bat`. Backup `.backup_edit_20261112_simple\` (V2 + V6); kiểm md5 đĩa trước/sau ghi. Quyết định: không fallback local (park B2), NMT song song chọn flavor theo glossary cũ/bảng bộ/base.
- **Kết quả / còn treo:** cloud: test mới 26/26 (25 + 1 skip khi không có golden); nhóm dịch cũ 246 pass/3 fail có sẵn (trước = sau); toàn bộ tests 362→387 pass, cùng danh sách fail môi trường; đầu-cuối golden 32da3d8f225b với LLM echo → eval trùng baseline job. Chưa: test Windows (bat), A/B thật (GPU+GPT khi V2 rảnh), restart :8801. Không LLM/GPU, không HTTP các cổng, không git.

## ~đêm — review độc lập translate-simple

- **Mục tiêu:** review + test kịch bản luồng `translate_simple/` trước A/B; sửa lỗi thật; file A/B cho chủ dự án.
- **Đã làm:** sửa `translate_simple/{cfg,lexicon,pipeline,plan_view,script_store,stage_draft,stage_review,validate}.py` + mới `suggest.py`, `data/lexicon/idioms_zh_vi.json`, `tests/test_translate_simple.py` (helper), mới `tests/test_translate_simple_scenarios.py` (19 ca). V6: mới `scripts/golden_ab_simple.bat`, sửa `scripts/test_v2_translate_simple.bat`. Backup `.backup_edit_20261112_simple_review\` (V2 + V6); kiểm md5 đĩa trước/sau ghi. `server.py` không đổi.
- **Kết quả:** cloud: simple 45/45; nhóm dịch cũ 246/3/5 (= trước); toàn bộ 388→407 pass, cùng danh sách fail; luồng mặc định server mới = backup (harness 21 kịch bản). Chưa: bat Windows, A/B thật. Không LLM/GPU, không HTTP các cổng, không git.

## ~khuya — translate-simple «next» (agent B)

- **Yêu cầu:** lexicon src + cờ loại golden_derived; bảng quy tắc xưng hô theo quan hệ; bổ sung cặp thiếu bằng 1 lần gọi model; học lại (cờ) + tools chỉ đọc (gom sửa tay → ứng viên golden, thống kê job); nguồn ZH (hardsub OCR thắng ASR, sửa tên); biến thể A/B; bổ sung agent A: simple không gỡ lặp ASR, đổi cặp theo cảnh.
- **Đã làm:** `translate_simple/{cfg,lexicon,pipeline,plan_view,post,suggest}.py` + mới `{pair_rules,pair_fill,zh_source}.py`, `data/lexicon/{idioms_zh_vi.json (src), pronoun_rules_zh_vi.json (mới)}`, mới `tools/{collect_manual_edits,simple_stats}.py`, mới `tests/test_translate_simple_next.py` (29 ca). V6 `golden_ab.py` (simple_noleak/simple_rules/simple_rules_fill/simple_rules_fill_zh), `golden_ab_simple.bat next`, `test_v2_translate_simple.bat`. Backup `.backup_edit_20261112_agentB\`.
- **Kết quả / còn treo:** cloud: next 29/29 (có backup), simple cũ 41+4 skip (= trước), nhóm dịch cũ 231/8 (= trước), toàn bộ 338→367 pass cùng 16 fail môi trường/có sẵn; cờ tắt trùng từng byte bản gốc. Chưa: bat Windows, A/B thật, video/OCR thật, pypinyin. Đề xuất cặp theo khoảng câu (chưa làm). Không LLM/GPU, không HTTP, không restart.

## ~khuya — review độc lập translate-simple «next» (agent D)

- **Yêu cầu:** review như người ngoài đợt «next» của agent B (cờ tắt byte-identical, pair_rules/pair_fill/zh_source, gỡ lặp ASR, golden_ab, tools chỉ đọc, ghi file/khoá); tự sửa lỗi cao/trung bình có test chứng minh.
- **Đã làm:** bản sao cloud (md5 khớp bảng sau ghi của B); 7 ca tái hiện lỗi FAIL trên bản B; sửa `translate_simple/{post,pipeline,zh_source}.py`, `data/lexicon/pronoun_rules_zh_vi.json`, `tools/collect_manual_edits.py`; test mới `tests/test_translate_simple_next_review.py`, 1 kỳ vọng trong `test_translate_simple_next.py`; V6 `test_v2_translate_simple.bat`. Backup `.backup_edit_20261112_agentD\` (V2 + V6); kiểm md5 đĩa trước/sau ghi.
- **Kết quả / còn treo:** simple+next 70→78 pass (4 skip); nhóm dịch cũ 231/8 (= trước); toàn bộ 367→375 pass, cùng 16 fail. Kết luận: an toàn chạy `golden_ab_simple.bat next`. Đề xuất chưa làm P1–P8 (lỗi «Đi mau,!» của luồng cũ trong translate.py, merge hardsub nhân đôi ngoài simple, golden_ab đặt cờ 0 tường minh…). Không LLM/GPU, không HTTP, không restart, không git.

## ~khuya — ASR mặc định trên giọng tách Demucs (agent E)

- **Yêu cầu:** (A) mọi job/part chạy Demucs trước ASR, 1 lần/job, dùng lại cho render; Demucs lỗi → fallback, không hỏng job; không đụng job ASR xong; (B) bỏ cắt cứng 60' segment FLAC — chia tại khoảng lặng, cắt/ghép theo mẫu, test độ dài từng mẫu; script A/B cho Windows + vocals cho golden CAM++.
- **Đã làm:** `asr.py` (`asr_use_demucs`, `resolve_asr_source` mới, `_asr_ui_phase`), `separate.py` (WAV RIFF/RF64 theo mẫu, `plan_chunks`, `outputs_valid`, resume `plan.json`, không ghi `audio.wav`), test mới `tests/test_separate_demucs_chunks.py` (19 ca; Demucs giả lập theo từng mẫu ⇒ so byte). V6: `scripts/asr_demucs_compare.{py,bat}`, `scratch/voice_exp/embed_campplus.py --vocals`. Rà nơi đọc `audio.wav` (chỉ ASR/repair + media_ts so độ dài) ⇒ không cần `orig_audio.wav`. Ước lượng RAM Demucs ~6–13 GB/giờ audio ⇒ giữ chia khúc 30'. Backup `.backup_edit_20261112_agentE\` (V2 + V6), md5 đĩa trước/sau ghi.
- **Kết quả / còn treo:** bản sao cloud: toàn bộ tests 375 → 395 pass, fail 16 → 15 (ca `test_asr_demucs` cũ nay pass), không fail mới; e2e script A/B với demucs giả + ffmpeg thật OK. Chưa: Demucs/FireRed thật trên GPU, đo chất lượng (chạy `asr_demucs_compare.bat run` khi V2 rảnh), port V4/V5/V6. Không GPU, không HTTP, không restart, không git.

## ~chiều — translate-simple thành mặc định (agent F2)

- **Yêu cầu:** chủ dự án chốt simple làm luồng dịch mặc định (A/B golden 92 % vs 35 % xưng hô, held-out 98,2 %), cờ con tắt, rollback `TRANSLATE_PIPELINE=legacy`; mọi đường gọi dịch (auto, stage, Dịch lại/Soát lại, translate-fill, rà theo yêu cầu Agent) đi đúng luồng; job dở luồng cũ không hỏng.
- **Đã làm:** `translate_simple/cfg.py` (`pipeline_default`, `LEGACY_VALUES`, `job_pipeline` + đóng dấu manifest), `translate_simple/__init__.py` (docstring), `server.py` (`_translate_pipeline_simple(wd, fresh)` + 7 điểm gọi), tests (`test_translate_simple.py` +6 ca F2, 4 ca chỉnh; b2/b2_review/b3 đặt legacy tường minh). V6 `test_v2_translate_simple.bat` (kỳ vọng 88). Backup `.backup_edit_20261112_agentF2\`; md5 đĩa = lúc đọc trước khi ghi, md5 sau ghi = bản sao.
- **Kết quả / còn treo:** bản sao cloud toàn bộ tests 480 → 486 pass, 21 fail môi trường (cùng danh sách trước/sau); simple+next 81 → 87 (+1 skip golden); nhóm dịch cũ 246/8 (= trước). Còn gọi helper luồng cũ (cố ý): translate-alts, pronoun/name pass của Agent, QA gate của job legacy. Có hiệu lực khi restart :8801. Không LLM/GPU, không HTTP, không restart, không git.

## ~sáng — Second Brain: Telegram spam + HOLD cũ + «tool chưa thực thi» (agent G)

- **Yêu cầu:** giảm tin Telegram (sự kiện hoặc ≥5–10'), gỡ HOLD job đã xong, sửa brain nói tool chưa chạy, DECISION chỉ khi có ý nghĩa; tìm nguyên nhân ASR `2937ffd7989f` (không chạy lại).
- **Đã làm:** `agent_brain.py` (events/digest/DECISION/deep focus/bằng chứng tool/`clear_stale_holds`/rule CLEAR qua `Manifest.update`), `agent_heal.py` (`note` plan rỗng), 2 khoá config (2 file), test mới `tests/test_agent_brain_events.py` (11). Backup `.backup_edit_20261112_agentG\`, md5 trước/sau. Dry-run chỉ đọc trên work thật: chỉ `f0834acf0cc0` đủ điều kiện gỡ HOLD.
- **Kết quả / còn treo:** cloud: toàn bộ tests 390→401 pass, cùng 17 fail + 12 error môi trường. Chờ restart :8801. Chưa: HOLD không chặn chạy tay TTS/mux (server.py — cần user chọn), watcher heal lúc khởi động (nghi giết ASR 2937), lưu stdout engine; port V4/V5/V6. Không LLM thật, không HTTP, không restart, không git.

## ~trưa — Second Brain: tin Telegram theo mẫu + HOLD chạy tay + race heal khởi động (agent H)

- **Yêu cầu:** (A) tin do code dựng theo mẫu, ngắn, không văn LLM/markdown/`<badge>`/`|`, 1 khối/job, DECISION chỉ log, lỗi nhắc ≤ 2 h; (B) chạy tay 1 bước trên job HOLD → tự gỡ HOLD + `hold_override` + 1 tin, brain/auto không HOLD lại khi chưa có high mới; (C) hoãn heal lúc khởi động ≥ 180 s, bỏ job đang chạy, lưu đuôi log engine.
- **Đã làm:** MỚI `agent_brain_notify.py`, `agent_hold.py`; sửa `agent_brain.py`, `agent_heal.py`, `agent_watch.py`, `server.py`, `routes_agent.py`; test mới `tests/test_agent_brain_notify.py` (28), chỉnh `tests/test_agent_brain_events.py` (G). Backup `.backup_edit_20261112_agentH\`, md5 trước khớp lúc đọc, `_md5_after.txt`. Dry-run chỉ đọc trên work thật (12 khối tin mẫu đúng mẫu).
- **Kết quả / còn treo:** cloud: toàn bộ tests 391 → 419 pass, cùng 27 fail + 12 error môi trường (danh sách trùng). Chờ restart :8801. Chưa: port V4/V5/V6; lệnh Telegram của user chưa tính là chạy tay; nguyên nhân gốc ASR mã 1 `2937ffd7989f` chờ log engine lần sau.

## ~chiều — Lệnh Telegram của người dùng = chạy tay, tự gỡ HOLD (agent I2)

- **Yêu cầu:** chủ dự án quyết «chạy tay thì tự gỡ HOLD» — lệnh người gửi qua Telegram (stage/dịch/tts/mux) cũng tính; brain/LLM tự phát không tính; phân biệt chắc nguồn, có test.
- **Đã làm:** `agent_tele_cmd.py` (header `X-Pineline-Caller: user` + `X-Pineline-Source: telegram` cho chat có uid và nút ✅), `agent_autopilot.py` (`caller_headers`, `_post(headers=)`), `routes_agent.py` (`/api/agent/chat|confirm` → `agent_hold.user_context`; hook heal/av-sync → `auto_context`; TTS của người không gỡ HOLD trước claim, `qa_override` qua `Manifest.update`), `agent_hold.py` (`user_context`, `manual_source`, `request_source`); test mới `tests/test_agent_hold_telegram.py` (14). Backup `.backup_edit_20261112_agentI2\`, md5 trước khớp lúc đọc, `_md5_after.txt`.
- **Kết quả / còn treo:** cloud: 14 ca mới fail trên code cũ, pass trên code mới; toàn bộ tests 431 → 445 pass, cùng 15 fail + 12 error môi trường. Chờ restart :8801 + bot Telegram :8802. Chưa: port V4/V5/V6; `resume_job` («Chạy tiếp») vẫn gỡ HOLD kiểu cũ không tin. Không LLM thật, không HTTP, không restart, không git.
