# brain-notify-v2: tin Telegram Second Brain theo mẫu + gỡ HOLD khi chạy tay + race heal lúc khởi động

- **Date:** 2026-11-12
- **Nguồn:** chủ dự án phàn nàn tin Telegram (hermes_bot) «nhiều, loạn, không hiểu đang báo gì» — agent H (tiếp nối agent G, `2026-11-12-brain-telegram-hold.md`).
- **Khu vực:** `agent_brain_notify.py` (MỚI), `agent_hold.py` (MỚI), `agent_brain.py`, `agent_heal.py`, `agent_watch.py`, `server.py`, `routes_agent.py`; test `tests/test_agent_brain_notify.py` (MỚI, 28 ca) + `tests/test_agent_brain_events.py` (G, chỉnh 6 kỳ vọng theo hành vi mới).
- **Status:** trên đĩa V2. **Có hiệu lực sau khi restart :8801** (brain/watcher/server in-process). Không cần restart :8802.
- **Backup:** `Z:\PinelineV2\.backup_edit_20261112_agentH\` (bản gốc 5 file + test G, `_md5_before.txt`, `_md5_after.txt`, `_new\` bản mới, `_src_for_tests.tgz`, `docs\`).

## Triệu chứng

1. Tin «Brain DECISION 2493d3c7cb29: **Job … ĐÃ XÁC MINH TRỰC TIẾP** | | <badge color="success">Đang chạy</badge> … | Stage | Trạng thái |…» — văn LLM cắt 350–400 ký tự, markdown bảng + thẻ `<badge>` (Telegram gửi plain text, không `parse_mode` → hiện nguyên ký tự), lặp mỗi vài phút.
2. «Brain LLM đã chạy: pineline_heal_job» — không nói kết quả (thành công? không có việc? lỗi?).
3. HOLD cũ ở lại sau khi người dùng chạy tay TTS/mux (`f0834acf0cc0`).
4. `2937ffd7989f` ASR fail 4 s (22:57:04→22:57:08 UTC = 05:57 giờ VN) đúng lúc :8801 khởi động, watcher log «heal 6/6 job(s) safe» cùng giây; không có chứng cứ (chỉ «firered_asr.py lỗi (mã 1)»).

## Nguyên nhân

1. Nội dung tin là chuỗi tự do (văn LLM / f-string rời rạc) đi thẳng vào `telegram_send` (plain text).
2. `llm_tick` chỉ liệt kê tên tool mutate, không đọc `result_preview`.
3. Đường chạy tay (`/run/{stage}`, `/tts`, `/mux`, `/translate`, `/translate-fill`) không đụng cờ HOLD; `_auto_gpu` chạy lại có thể đặt lại HOLD qa_brain.
4. Watcher `_loop` gọi `watch_once` NGAY lúc start (heal_stale + heal safe trên mọi job lỗi) trong khi hàng đợi đang nối lại job cũ; `heal_job` không kiểm job đang là `queue.current` / có engine sống; `_run_engine` vứt stdout khi engine lỗi. (Giả thuyết: heal/stale lúc khởi động đụng job ASR vừa spawn → `_kill_job_engine_procs`/reset stage → engine thoát mã 1. Không tái hiện được vì không có log — nay đã lưu đuôi log.)

## Sửa

### A. Tin do CODE dựng theo mẫu (`agent_brain_notify.py`)
- `render_job(jid, data, events)` → 1 khối/job: tiêu đề `emoji + tên phim VI rút gọn + P<n> + (id 6 ký tự[_pNN])` + ≤ 3 dòng (chuyện gì / brain làm gì + KẾT QUẢ / «Cần bạn: …»). `render_tick` gộp mọi khối của 1 tick thành 1 tin (cách dòng trống).
- Tên: `title_vi` → `meta.title_vi` → `series_vi` → title gốc; part con `_pNN` không có title_vi → lấy của job cha. Rút gọn: bỏ «Phần N» (→ `PN`), cắt ở `: , - ; ( ! ?` đầu tiên (≥ 2 từ), ≤ 40 ký tự. Part con + phần phim → `P3.2`.
- `clean()`: bỏ thẻ `<…>`, `** __ ~~ \``, `#`, đổi `|` → `,`, gộp khoảng trắng. Giờ «lúc HH:MM» theo giờ máy (hoặc `AGENT_BRAIN_TZ`, vd `+7`).
- Sự kiện (`agent_brain._emit` / `detect_stage_events` trả dict): `stage_start/done/failed`, `job_done`, `hold_set` (diff cờ HOLD), `hold_cleared` (job_done / qa_clean / manual), `heal` (`heal_summary`: ok/noop/fail/deferred/skipped + action), `llm_action` (`tool_outcome` đọc `result_preview`), `remind_failed`.
- **DECISION/văn LLM không lên Telegram** (chỉ `agent_brain.log` dòng `LLM DECISION …`). Tool mutate thật của LLM → «Brain: heal job → không có việc để làm.» / «… → thất bại: <lý do>.»
- Khử lặp: lỗi cùng job+stage báo 1 lần khi chuyển sang failed; nhắc lại ≥ `AGENT_BRAIN_REMIND_SEC` (7200 s), tối đa `AGENT_BRAIN_REMIND_MAX` (3) lần. Kết quả heal / hành động LLM cùng (job, kết quả, action) → tối đa 1 lần / 2 h. Job chạy bình thường: chỉ tin chuyển stage.
- Watcher (`agent_watch.watch_once`) dùng cùng mẫu («Watcher: tự sửa (render lại) → thành công.»), chỉ khi có action thành công.
- Thứ tự tick: `clear_stale_holds` trước `detect_stage_events` → «✅ … — xong, có video. Đã gỡ HOLD cũ.» 1 dòng.

### B. Gỡ HOLD khi chạy tay (`agent_hold.py`)
- `server._manual_hold_override(request, job_id, stage, source)` gọi sau khi claim thành công trong `run_stage` (`/api/jobs/{id}/run/{stage}`), `translate_fill`, `regen_tts` (`/tts`), `retranslate_job` (`/translate`), `mux_job` (`/mux`). Thêm tham số `request: Request = None` (FastAPI tiêm; gọi Python trực tiếp từ agent/heal/queue = `None` → KHÔNG override).
- Phân biệt tay/tự động: `is_manual_request` — HTTP từ UI/WebView; header `X-Pineline-Caller` (brain gắn `brain`) hoặc UA `Python-urllib/requests/httpx` → không phải tay.
- Job đang HOLD (`qa_blocked`/`hold_after_translate`/`held_at`) → `Manifest.update`: cờ = false, bỏ `held_at`/`hold_reason`, `agent.hold_override = {by:"manual", stage, at, ts, source, was, high, high_i}`, `translate.cur_text` «HOLD đã gỡ (bạn chạy tay …)»; log `agent_brain.log`; 1 tin «🔓 <phim> (id) / Đã gỡ HOLD vì bạn chạy tay <stage>.» (luồng nền, không chặn request).
- Không HOLD lại: `agent_hold.hold_suppressed(wd)` = có override tay và `qa_brain.json` KHÔNG có high mới (số high tăng hoặc chỉ số câu mới). Áp ở `server._auto_gpu` (HOLD qa_brain), `routes_agent._agent_set_hold(enabled=True)` khi đang trong `agent_hold.auto_context("brain")` (brain bọc mọi lời gọi LLM), và `set_hold` của runtime FS/HTTP trong brain (nay ghi qua `Manifest.update`, không `write_text` thô).

### C. Race heal lúc khởi động
- `AGENT_HEAL_START_DELAY_SEC` (mặc định 180, `config.json`/env): watcher chờ trước lượt `watch_once` đầu; brain bỏ action `heal_job` + bỏ LLM tick trong thời gian hoãn (log «hoãn heal — vừa khởi động»). Sự kiện/gỡ HOLD cũ vẫn chạy.
- `agent_heal.job_active(jid, hooks)`: `queue.current` (cả part `_pNN` của job cha), hook `job_active` (`routes_agent._HEAL_HOOKS`: `_job_proc_alive` / `_job_lineage_busy`) → `heal_job(apply=True)` trả `skipped` không làm gì; watcher không gọi `heal_stale` cho job đó; brain log «heal … bỏ qua — job đang chạy».
- `server._run_engine`: giữ 40 dòng stdout/stderr cuối (bỏ dòng rác `_noisy_log`); engine lỗi → `work/<job>/engine_fail_<script>.log` + `stages.<asr|tts|ocr|separate>.engine_tail/engine_rc/engine_fail_log/engine_fail_at` (qua `Manifest.update`). Thông điệp lỗi giữ nguyên («… lỗi (mã N)») để phân loại cũ không đổi.

## Config (mặc định trong code, KHÔNG sửa config.json)

| Khoá | Mặc định | Ý nghĩa |
|---|---|---|
| `AGENT_BRAIN_TELEGRAM` | `events` (G) | events/minimal/report/all/off |
| `AGENT_BRAIN_REMIND_SEC` | 7200 | nhắc lại lỗi / kết quả hành động cùng loại |
| `AGENT_BRAIN_REMIND_MAX` | 3 | số lần nhắc tối đa / lỗi |
| `AGENT_BRAIN_TZ` | (giờ máy) | `+7` nếu máy không đặt giờ VN |
| `AGENT_HEAL_START_DELAY_SEC` | 180 | hoãn heal watcher/brain sau start |

`AGENT_BRAIN_DECISION_DEDUP_SEC` (G) không còn dùng.

## Tin mẫu (dry-run chỉ đọc trên `D:\PinelineV2_work` thật, 12/11)

```
❌ Lớp học huyền thoại bị lộ P3 (2937ff)
ASR lỗi (firered mã 1) lúc 05:57.
Brain: chẩn đoán xong, heal an toàn không có việc để làm.
Cần bạn: xếp lại ASR khi GPU rảnh.

✅ Độc Đế Vô Song 3D P6 (f0834a) — xong, có video. Đã gỡ HOLD cũ.

▶️ Xâm nhập trò chơi P4 (2493d3_p04) — bắt đầu Render

▶️ Xâm nhập trò chơi P2 (2493d3_p02) — xong ASR, bắt đầu Dịch

🔓 Độc Đế Vô Song 3D P6 (f0834a)
Đã gỡ HOLD vì bạn chạy tay Lồng tiếng.

⏸ Độc Đế Vô Song 3D P6 (f0834a)
Đã đặt HOLD: Second Brain: 1 high QA — chặn TTS/mux.
Cần bạn: duyệt bản dịch rồi bấm Chạy tiếp (hoặc chạy tay Lồng tiếng).
```

## Recheck (sau restart :8801)

- Pass nếu: `agent_brain.log` có `brain start … tg=events heal_delay=180s`, `agent_watch.log` có `hoãn heal 180s sau khởi động`; 3 phút đầu không có `heal N/N job(s)`; tin Telegram đúng mẫu trên (không `|`, không `<badge>`, không «Brain DECISION»); tick đầu: 1 tin «✅ Độc Đế Vô Song 3D P6 (f0834a) — xong, có video. Đã gỡ HOLD cũ.»; bấm chạy tay TTS/mux trên job HOLD → manifest có `agent.hold_override`, 1 tin «🔓 … Đã gỡ HOLD vì bạn chạy tay …»; engine lỗi → có `engine_fail_*.log` trong thư mục job.
- Fail nếu: còn văn LLM/markdown trên Telegram; cùng lỗi báo lại < 2 h; job đã override bị HOLD qa_brain lại khi QA không có high mới.
- Test: `python -m pytest -q tests\test_agent_brain_notify.py tests\test_agent_brain_events.py` (39 pass). Toàn bộ `tests/` bản sao cloud (AGENT_BRAIN=0): trước 391 pass / 27 fail / 12 error (môi trường thiếu fastapi/google), sau 419 pass / cùng 27 fail / 12 error — không fail mới.

## Còn lại / đề xuất

- ~~Lệnh Telegram của user KHÔNG được tính là «chạy tay»~~ → đã làm, xem mục D (agent I2).
- `routes_agent._agent_set_hold` / `server._auto_gpu` vẫn ghi bằng `m.save()` (merge3) — nên chuyển `Manifest.update`.
- Nguyên nhân gốc ASR mã 1 của `2937ffd7989f` vẫn là giả thuyết — lần lỗi sau xem `engine_fail_firered_asr.log`.

## D. Lệnh Telegram của người dùng = chạy tay (agent I2, 12/11 chiều)

- **Quyết định chủ dự án:** «chạy tay thì tự gỡ HOLD» áp cả cho lệnh người gõ trên Telegram (stage/dịch/TTS/mux). Lệnh brain/LLM tự phát KHÔNG tính.
- **Đường đi thật:** tin Telegram → `agent_tele_cmd._agent_ask` → `agent_autopilot.agent_chat` (requests) → `POST /api/agent/chat` → `agent_core.run_agent` → tool (`pineline_run_stage[_wait]`, `pipeline_loop`, `tts_run`, `asr_run`, `ocr_run`, `mux_run`) → hook `routes_agent._agent_run_stage`/`_agent_mux_run` → `S.run_stage`/`S.mux_job` gọi **Python trực tiếp, request=None** (trước: không bao giờ gỡ HOLD). Tool `force=true` đỗ lại → người bấm ✅ → `POST /api/agent/confirm` → `confirm_action`.
- **Sửa:**
  - `agent_tele_cmd.py`: `_agent_ask` gửi `X-Pineline-Caller: user` + `X-Pineline-Source: telegram` CHỈ khi có `uid` (uid đã qua `allowed_uids`); `/cmd` nội bộ (uid rỗng) không gắn. `_confirm_callback` (người bấm ✅) gắn như trên.
  - `agent_autopilot.py`: `caller_headers()`, `_post(headers=)`, `agent_chat/agent_confirm(caller=, source=)` (mặc định không gắn → tick Auto-pilot không đổi).
  - `routes_agent.py`: `api_agent_chat`/`api_agent_confirm` nhận `request: Request`; request tay (`agent_hold.is_manual_request`: header `user|ui|manual` hoặc UI/WebView) → chạy `run_agent`/`confirm_action` trong `agent_hold.user_context("agent_chat:<nguồn>")`. `_HEAL_HOOKS`/`_AV_SYNC_HOOKS` bọc `_as_auto` → `auto_context("heal"|"av_sync")` (heal tự quyết không tính tay kể cả khi người gõ «heal»). `_agent_run_stage("tts")` trong ngữ cảnh người: KHÔNG gỡ HOLD trước claim (để `S.run_stage` gỡ sau claim → `hold_override` + 1 tin «🔓»), claim OK + job QA-block → `agent.qa_override=True` qua `Manifest.update` (giữ ngữ nghĩa cũ); claim lỗi (409 bận) → HOLD giữ nguyên.
  - `agent_hold.py`: `user_context`, `user_caller`, `request_source`, `manual_source(request)` — `auto_context` (brain/heal) luôn thắng; `maybe_manual_override` dùng `manual_source`, `source` ghi `run_stage+agent_chat:telegram` / `mux+agent_confirm:telegram`. Ngữ cảnh là thread-local (route sync chạy trọn trong 1 luồng threadpool; luồng brain/queue khác không thấy).
- **Không tính tay:** brain in-process (`auto_context("brain")`), brain HTTP fallback (header `brain`), Auto-pilot/script (`python-requests`/urllib không header), heal/av-sync hook, `/cmd` nội bộ không uid.
- **Lưu ý:** tool KHÔNG `force` (vd `pineline_tts_run` thường) chạy ngay trong lượt chat của người (không cần ✅) → cũng tính tay vì người đã gõ lệnh. `pineline_resume_job` («Chạy tiếp») vẫn gỡ HOLD kiểu cũ (`m.save()`, không `hold_override`/tin) — ngoài phạm vi.
- **Test:** MỚI `tests/test_agent_hold_telegram.py` (14 ca: ma trận nguồn, thread-local, chat/✅ Telegram gỡ HOLD + 1 tin + `qa_override`, autopilot/brain HTTP/brain in-process/heal hook không gỡ, job bận giữ HOLD, header client). Trên code trước sửa: 14/14 fail. Bản sao cloud (AGENT_BRAIN=0): `test_agent_hold_telegram + test_agent_brain_notify + test_agent_brain_events` 53 pass; toàn bộ `tests/` trước 431 pass / 15 fail / 12 error → sau 445 pass / cùng 15 fail / 12 error (thiếu fastapi/google/soundfile).
- **Hiệu lực:** restart :8801 (routes_agent/agent_hold/agent_autopilot in-process) **và** tiến trình bot Telegram `agent_tele_cmd` (:8802). Recheck: gõ trên Telegram «lồng tiếng lại <job HOLD>» (hoặc bấm ✅ lệnh force) → manifest `agent.hold_override.source` chứa `agent_chat:telegram`/`agent_confirm:telegram` + 1 tin «🔓 … Đã gỡ HOLD vì bạn chạy tay …»; brain tick không tạo `hold_override`.
- **Backup:** `Z:\PinelineV2\.backup_edit_20261112_agentI2\` (`_md5_before.txt`, `_md5_after.txt`, `_new\`, `_src_for_tests.tgz`, `docs\`).

## Port (V4/V5/V6 CHƯA sửa)

File V2 phần brain/hold/heal đổi trong ngày 12/11 (G + H): `agent_brain.py`, `agent_heal.py`, `agent_watch.py`, `server.py` (`_manual_hold_override`, 5 route, `_auto_gpu` qa_brain, `_run_engine` + `_save_engine_tail`), `routes_agent.py` (`_HEAL_HOOKS.job_active`, `_agent_set_hold`), MỚI `agent_brain_notify.py`, `agent_hold.py`; config `config.json` + `pineline.config.json` (G: `AGENT_BRAIN_TELEGRAM`, `AGENT_BRAIN_TG_SEC`); tests `tests/test_agent_brain_events.py`, `tests/test_agent_brain_notify.py`. Agent I2 thêm: `agent_tele_cmd.py`, `agent_autopilot.py`, `routes_agent.py` (`_agent_user_ctx`, `_as_auto`, `_agent_run_stage`), `agent_hold.py` (`user_context`/`manual_source`), test `tests/test_agent_hold_telegram.py`. V5/V6 tương ứng `agents/agent_brain.py`, `agents/agent_heal.py`, `agents/agent_watch.py`, router agent; V6 ghi manifest qua `state/job_state.py`.
