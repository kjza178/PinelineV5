import sys, pathlib
root = pathlib.Path(sys.argv[1])
def edit(rel, fn):
    p = root / rel
    b = p.read_bytes()
    bom = b.startswith(b"\xef\xbb\xbf")
    t = b.decode("utf-8-sig")
    crlf = "\r\n" in t
    t = t.replace("\r\n", "\n")
    t2 = fn(t)
    assert t2 != t, rel
    if crlf: t2 = t2.replace("\n", "\r\n")
    p.write_bytes((b"\xef\xbb\xbf" if bom else b"") + t2.encode("utf-8"))
    print("ok", rel, "crlf" if crlf else "lf", "bom" if bom else "")
CH = ("- **Second Brain: tin Telegram dựng theo MẪU + gỡ HOLD khi chạy tay + hoãn heal lúc khởi động** (agent H, chủ dự án: tin «nhiều, loạn, không hiểu»). "
      "MỚI `agent_brain_notify.py` (1 khối/job: emoji + tên phim VI rút gọn + P<n> + id rút gọn + ≤3 dòng chuyện gì / brain làm gì + kết quả / «Cần bạn»; plain text, bỏ markdown/`<badge>`/`|`); "
      "`agent_brain.py`: sự kiện có cấu trúc (`_emit`, `detect_stage_events` → dict, `hold_set`, nhắc lỗi ≤ mỗi 2 h ×3), văn DECISION LLM chỉ vào log, tool mutate LLM → tin «Brain: … → kết quả», heal rule path kèm kết quả, hoãn heal+LLM 180 s sau start, runtime `set_hold` qua `Manifest.update`; "
      "`agent_watch.py`: chờ `AGENT_HEAL_START_DELAY_SEC` (180) trước lượt heal đầu, bỏ job đang chạy, tin theo mẫu; `agent_heal.py`: `start_delay_sec`, `job_active` (queue.current / engine sống / claim) → `heal_job` không làm gì; "
      "MỚI `agent_hold.py` + `server.py` `_manual_hold_override` trong `/run/{stage}`, `/tts`, `/mux`, `/translate`, `/translate-fill` (chỉ request HTTP từ UI): job HOLD → gỡ cờ + `agent.hold_override` + 1 tin; `_auto_gpu`/`_agent_set_hold`(brain) không HOLD lại khi chưa có high mới; "
      "`_run_engine` lưu 40 dòng cuối vào `engine_fail_<script>.log` + `stages.<stage>.engine_tail`. `routes_agent.py`: hook `job_active`. Test mới `tests/test_agent_brain_notify.py` (28), `test_agent_brain_events.py` chỉnh 6 kỳ vọng. Config mới (mặc định trong code): `AGENT_BRAIN_REMIND_SEC`, `AGENT_BRAIN_REMIND_MAX`, `AGENT_BRAIN_TZ`, `AGENT_HEAL_START_DELAY_SEC`. "
      "**Restart :8801.** Port V4/V5/V6 CHƯA sửa. Bak `.backup_edit_20261112_agentH\\`. Fix `docs/fixes/2026-11-12-brain-notify-v2.md`.")
def ch(t):
    k = "## 2026-11-12\n\n"
    i = t.index(k) + len(k)
    return t[:i] + CH + "\n" + t[i:]
ST = ("- **11-12 — Second Brain tin theo MẪU + gỡ HOLD khi chạy tay + hoãn heal 180 s (agent H) — chờ restart :8801:** tin Telegram do code dựng (vd «❌ Lớp học huyền thoại bị lộ P3 (2937ff) / ASR lỗi (firered mã 1) lúc 05:57. / Brain: … / Cần bạn: …»), không còn «Brain DECISION»/văn LLM; cùng lỗi nhắc ≤ 2 h. "
      "Chạy tay TTS/mux/dịch trên job HOLD → tự gỡ HOLD (`agent.hold_override`) + 1 tin; brain/auto không HOLD lại nếu QA không có high mới. Watcher/brain hoãn heal 180 s sau start, không heal job đang chạy; engine lỗi → `engine_fail_*.log` trong thư mục job. "
      "Port V4/V5/V6 chưa làm. Fix `docs/fixes/2026-11-12-brain-notify-v2.md`.")
def st(t):
    k = "## Việc còn treo / cần user quyết\n\n"
    i = t.index(k) + len(k)
    return t[:i] + ST + "\n" + t[i:]
WL = ("\n## ~trưa — Second Brain: tin Telegram theo mẫu + HOLD chạy tay + race heal khởi động (agent H)\n\n"
      "- **Yêu cầu:** (A) tin do code dựng theo mẫu, ngắn, không văn LLM/markdown/`<badge>`/`|`, 1 khối/job, DECISION chỉ log, lỗi nhắc ≤ 2 h; (B) chạy tay 1 bước trên job HOLD → tự gỡ HOLD + `hold_override` + 1 tin, brain/auto không HOLD lại khi chưa có high mới; (C) hoãn heal lúc khởi động ≥ 180 s, bỏ job đang chạy, lưu đuôi log engine.\n"
      "- **Đã làm:** MỚI `agent_brain_notify.py`, `agent_hold.py`; sửa `agent_brain.py`, `agent_heal.py`, `agent_watch.py`, `server.py`, `routes_agent.py`; test mới `tests/test_agent_brain_notify.py` (28), chỉnh `tests/test_agent_brain_events.py` (G). Backup `.backup_edit_20261112_agentH\\`, md5 trước khớp lúc đọc, `_md5_after.txt`. Dry-run chỉ đọc trên work thật (12 khối tin mẫu đúng mẫu).\n"
      "- **Kết quả / còn treo:** cloud: toàn bộ tests 391 → 419 pass, cùng 27 fail + 12 error môi trường (danh sách trùng). Chờ restart :8801. Chưa: port V4/V5/V6; lệnh Telegram của user chưa tính là chạy tay; nguyên nhân gốc ASR mã 1 `2937ffd7989f` chờ log engine lần sau.\n")
def wl(t):
    return t.rstrip("\n") + "\n" + WL
edit("docs/CHANGELOG.md", ch)
edit("docs/STATE.md", st)
edit("docs/worklog/2026-11-12.md", wl)
