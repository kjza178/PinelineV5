"""Dry-run (chỉ đọc) — dựng tin mẫu từ manifest thật trong work root. Không ghi gì."""
import json, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])          # thư mục chứa agent_brain_notify.py mới
import agent_brain_notify as nt
work = Path(sys.argv[2])
tz = nt.tz_from_cfg("+7")
dirs = sorted([d for d in work.iterdir() if (d / "manifest.json").is_file()],
              key=lambda d: (d / "manifest.json").stat().st_mtime, reverse=True)[:25]
def rd(p):
    try: return json.loads(p.read_text(encoding="utf-8"))
    except Exception: return None
out = []
for d in dirs:
    data = rd(d / "manifest.json")
    if not data: continue
    base, part = nt.split_part(d.name)
    parent = rd(work / base / "manifest.json") if part is not None else None
    st = data.get("stages") or {}
    evs = []
    for s in ("download", "asr", "translate", "tts", "mux"):
        v = st.get(s) or {}
        if v.get("status") == "failed":
            evs.append({"kind": "stage_failed", "stage": s, "error": v.get("error"), "at": v.get("finished_at") or v.get("updated_at")})
        elif v.get("status") == "running":
            evs.append({"kind": "stage_start", "stage": s})
    ag = data.get("agent") or {}
    held = any(ag.get(k) for k in ("qa_blocked", "hold_after_translate", "held_at"))
    has_out = (d / "output.mp4").is_file() and (d / "output.mp4").stat().st_size > 0
    mux_done = str((st.get("mux") or {}).get("status")) in ("done", "ok", "completed")
    if mux_done and has_out and not any(e["kind"] == "stage_start" for e in evs):
        evs.append({"kind": "job_done"})
        if held: evs.append({"kind": "hold_cleared", "why": "job_done"})
    elif held:
        evs.append({"kind": "hold_set", "reason": ag.get("hold_reason") or ag.get("held_at")})
    if any(e["kind"] == "stage_failed" for e in evs):
        evs.append({"kind": "heal", "by": "brain", "outcome": "noop", "actions": []})
    if evs:
        out.append(nt.render_job(d.name, data, evs, parent=parent, tz=tz))
print(nt.render_tick(out[:12]))
