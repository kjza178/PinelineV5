"""ASR engine variants."""
